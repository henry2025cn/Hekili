Hekili_mode_dict = {
    single = "单",
    aoe = "群",
    dual = "双",
    reactive = "响",
    automatic = "自",
}

-- 全局变量：记录按钮是否隐藏
local areButtonsHidden = false

local warriorSpecialSpellIcons = {}

function ChangeButtonColor(button, IsActive)
    
    if not button or not button.GetFontString then return end  -- 添加空值检查

    local r, g, b
    if IsActive then
        r, g, b = 0, 1, 0
    else
        r, g, b = 0.5, 0.5, 0.5
    end
    button:GetFontString():SetTextColor(r, g, b)
end

local function IsWarrior()
    local _, englishClass = UnitClass("player")
    return englishClass == "WARRIOR"
end

local function showWarriorSpecialIcon()
    if not IsWarrior() or not Hekili then return end
    local heroic_strike_id = 47450
    local cleave_id = 47520
    local active_enemies = Hekili.State.active_enemies
    local rage = UnitPower("player", Enum.PowerType.Rage)                      --玩家怒气
    local rageThreshold = Hekili.DB.profile.specs[ 1 ].settings.heroic_strike_rage_threshold
    --print("active_enemies, rage, rageThreshold",active_enemies, rage, rageThreshold)
    if InCombatLockdown() and warriorSpecialSpellIcons[heroic_strike_id] and warriorSpecialSpellIcons[cleave_id] then
        if active_enemies>=2 and rage>=rageThreshold then
            warriorSpecialSpellIcons[cleave_id].frame:Show()
            warriorSpecialSpellIcons[heroic_strike_id].frame:Hide()
        elseif active_enemies==1 and rage>=rageThreshold then
            warriorSpecialSpellIcons[heroic_strike_id].frame:Show()
            warriorSpecialSpellIcons[cleave_id].frame:Hide()
        else
            warriorSpecialSpellIcons[heroic_strike_id].frame:Hide()
            warriorSpecialSpellIcons[cleave_id].frame:Hide()
        end
    end
    if not InCombatLockdown() or not UnitExists("target") or not UnitCanAttack("player", "target") and warriorSpecialSpellIcons and warriorSpecialSpellIcons[heroic_strike_id] and  warriorSpecialSpellIcons[cleave_id] then
        warriorSpecialSpellIcons[heroic_strike_id].frame:Hide()
        warriorSpecialSpellIcons[cleave_id].frame:Hide()
    end
end

function Hekili_Btn_UpdateButton()
    if not HekiliDisplayPrimary or not Hekili.DB.profile.btnFunction or areButtonsHidden then return end
    if HekiliDisplayPrimary then
        if Hekili_Btnbutton1 then ChangeButtonColor(Hekili_Btnbutton1, Hekili.DB.profile.toggles.cooldowns.value) end
        if Hekili_Btnbutton2 then ChangeButtonColor(Hekili_Btnbutton2, Hekili.DB.profile.toggles.essences.value) end
        if Hekili_Btnbutton3 then ChangeButtonColor(Hekili_Btnbutton3, Hekili.DB.profile.toggles.interrupts.value) end
        if Hekili_Btnbutton4 then ChangeButtonColor(Hekili_Btnbutton4, Hekili.DB.profile.toggles.defensives.value) end
        if Hekili_Btnbutton5 then ChangeButtonColor(Hekili_Btnbutton5, Hekili.DB.profile.toggles.potions.value) end 
        if Hekili_Btnbutton6 then
            Hekili_Btnbutton6:SetText(Hekili_mode_dict[Hekili.DB.profile.toggles.mode.value])
            ChangeButtonColor(Hekili_Btnbutton6, Hekili.DB.profile.toggles.mode.value)
        end
    end
end

local function createIconForSpell(spellIconlist, spellId, spellTexture)
    -- 如果不存在，创建新的 Frame 和 Texture
    local frame = CreateFrame("Frame", nil, UIParent)
    frame:SetSize(Hekili.DB.profile.displays.Primary.primaryWidth, Hekili.DB.profile.displays.Primary.primaryHeight)
    --frame:SetPoint("CENTER", BBRotDB.hx+1000, BBRotDB.h)
    frame:SetPoint("BOTTOMLEFT", HekiliDisplayPrimary, "BOTTOMLEFT", 0, -Hekili.DB.profile.displays.Primary.primaryHeight) -- Y偏移-36让图标完全显示
    local texture = frame:CreateTexture(nil, "ARTWORK")
    texture:SetAllPoints(frame)
    texture:SetTexture(spellTexture)

    spellIconlist[spellId] = {frame = frame, texture = texture}
end

-- 新增：切换按钮显示/隐藏
local function ToggleButtonsVisibility()
    areButtonsHidden = not areButtonsHidden
    for i = 1, 6 do
        local button = _G["Hekili_Btnbutton"..i]
        if button then
            button:SetShown(not areButtonsHidden)
        end
    end
    -- 更新控制按钮文本（▼表示隐藏，▲表示显示）
    if Hekili_ControlButton then
        Hekili_ControlButton:SetText(areButtonsHidden and "▲" or "▼")
    end
end



--控制按钮
function Hekili_Btn_CreateBtnFrame()
    Hekili_BtnFrame = CreateFrame("Frame", "BtnFrame")
    Hekili_BtnFrame:SetSize(20, 30)

    -- 新增：控制按钮（用于隐藏/显示其他按钮）
    Hekili_ControlButton = CreateFrame("Button", "Hekili_ControlButton", Hekili_BtnFrame, "UIPanelButtonTemplate")
    Hekili_ControlButton:SetSize(20, 10)  -- 高度为长度的一半
    Hekili_ControlButton:SetPoint("TOPLEFT", 0, 0)
    Hekili_ControlButton:SetText("▼")
    Hekili_ControlButton:GetFontString():SetTextColor(1, 1, 1)  -- 白色文本
    Hekili_ControlButton:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    Hekili_ControlButton:SetScript("OnClick", function(_, button)
        if button == "LeftButton" then
            ToggleButtonsVisibility()
        elseif button == "RightButton" then
            print("RightButton")
            ChatFrame1EditBox:SetText("/hekili")
            ChatEdit_SendText(ChatFrame1EditBox)
        end
    end)

    Hekili_Btnbutton1 = CreateFrame("Button", "Hekili_Btnbutton1", Hekili_BtnFrame, "UIPanelButtonTemplate")
    Hekili_Btnbutton1:SetSize(20, 20)
    Hekili_Btnbutton1:SetPoint("TOPLEFT", Hekili_BtnFrame, "TOPLEFT", 0, -10)
    Hekili_Btnbutton1:SetText("主")
    Hekili_Btnbutton1:GetFontString():SetTextColor(0.5, 0.5, 0.5)
    Hekili_Btnbutton1:SetScript("OnClick", function()
        Hekili:FireToggle("cooldowns")
        Hekili_Btn_UpdateButton()
    end)

    Hekili_Btnbutton2 = CreateFrame("Button", "Hekili_Btnbutton2", Hekili_BtnFrame, "UIPanelButtonTemplate")
    Hekili_Btnbutton2:SetSize(20, 20)
    Hekili_Btnbutton2:SetPoint("TOPLEFT", Hekili_BtnFrame, "TOPLEFT", 20, -10)
    Hekili_Btnbutton2:SetText("次")
    Hekili_Btnbutton2:GetFontString():SetTextColor(0, 1, 0)
    Hekili_Btnbutton2:SetScript("OnClick", function()
        Hekili:FireToggle("essences")
        Hekili_Btn_UpdateButton()
    end)

    Hekili_Btnbutton3 = CreateFrame("Button", "Hekili_Btnbutton3", Hekili_BtnFrame, "UIPanelButtonTemplate")
    Hekili_Btnbutton3:SetSize(20, 20)
    Hekili_Btnbutton3:SetPoint("TOPLEFT", Hekili_BtnFrame, "TOPLEFT", 40, -10)
    Hekili_Btnbutton3:SetText("断")
    Hekili_Btnbutton3:GetFontString():SetTextColor(0, 1, 0)
    Hekili_Btnbutton3:SetScript("OnClick", function()
        Hekili:FireToggle("interrupts")
        Hekili_Btn_UpdateButton()
    end)

    Hekili_Btnbutton4 = CreateFrame("Button", "Hekili_Btnbutton4", Hekili_BtnFrame, "UIPanelButtonTemplate")
    Hekili_Btnbutton4:SetSize(20, 20)
    Hekili_Btnbutton4:SetPoint("TOPLEFT", Hekili_BtnFrame, "TOPLEFT", 60, -10)
    Hekili_Btnbutton4:SetText("防")
    Hekili_Btnbutton4:GetFontString():SetTextColor(0, 1, 0)
    Hekili_Btnbutton4:SetScript("OnClick", function()
        Hekili:FireToggle("defensives")
        Hekili_Btn_UpdateButton()
    end)

    Hekili_Btnbutton5 = CreateFrame("Button", "Hekili_BtnButton5", Hekili_BtnFrame, "UIPanelButtonTemplate")
    Hekili_Btnbutton5:SetSize(20, 20)
    Hekili_Btnbutton5:SetPoint("TOPLEFT", Hekili_BtnFrame, "TOPLEFT", 80, -10)
    Hekili_Btnbutton5:SetText("药")
    Hekili_Btnbutton5:GetFontString():SetTextColor(0, 1, 0)
    Hekili_Btnbutton5:SetScript("OnClick", function()
        Hekili:FireToggle("potions")
        Hekili_Btn_UpdateButton()
    end)

    Hekili_Btnbutton6 = CreateFrame("Button", "Hekili_BtnButton6", Hekili_BtnFrame, "UIPanelButtonTemplate")
    Hekili_Btnbutton6:SetSize(20, 20)
    Hekili_Btnbutton6:SetPoint("TOPLEFT", Hekili_BtnFrame, "TOPLEFT", 100, -10)
    Hekili_Btnbutton6:SetText(Hekili_mode_dict[Hekili.DB.profile.toggles.mode.value])
    Hekili_Btnbutton6:GetFontString():SetTextColor(0, 1, 0)
    Hekili_Btnbutton6:SetScript("OnClick", function()
        Hekili:FireToggle("mode")
        Hekili_Btnbutton6:SetText(Hekili_mode_dict[Hekili.DB.profile.toggles.mode.value])
    end)
    Hekili_Btn_UpdateButton()
end

local function UpdateBtnFrameVisibility()
    if HekiliDisplayPrimary and Hekili.DB.profile.btnFunction then
        if not Hekili_BtnFrame then
            Hekili_Btn_CreateBtnFrame()
            Hekili_BtnFrame:ClearAllPoints() -- 清除原来的位置
            Hekili_BtnFrame:SetPoint("TOPLEFT", HekiliDisplayPrimary, "TOPLEFT", 0, 30)
            if IsWarrior() then
                createIconForSpell(warriorSpecialSpellIcons, 47450, GetSpellTexture(47450))
                createIconForSpell(warriorSpecialSpellIcons, 47520, GetSpellTexture(47520))
            end
        end
        Hekili_BtnFrame:Show()
    elseif Hekili_BtnFrame then
        Hekili_BtnFrame:Hide()
    end
end

C_Timer.After(1, UpdateBtnFrameVisibility)

-- 优化后的 OnUpdate（降低频率）
local lastUpdate = 0
local frame = CreateFrame("Frame")
frame:SetScript("OnUpdate", function(_, elapsed)
    lastUpdate = lastUpdate + elapsed
    if lastUpdate > 0.2 and HekiliDisplayPrimary then  -- 每0.2秒更新一次
        Hekili_Btn_UpdateButton()
        UpdateBtnFrameVisibility()
        if IsWarrior() then
            showWarriorSpecialIcon()
        end
        lastUpdate = 0
    end
end)
