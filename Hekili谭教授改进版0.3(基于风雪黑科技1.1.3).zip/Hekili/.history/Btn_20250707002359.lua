-- 模式字典（保持不变）
Hekili_mode_dict = {
    single = "单", aoe = "群", dual = "双", 
    reactive = "响", automatic = "自"
}

-- 全局变量
local areButtonsHidden = false
local isDragging = false
local dragStartX, dragStartY = 0, 0
local frameStartX, frameStartY = 0, 0

-- 按钮颜色设置（保持不变）
function ChangeButtonColor(button, IsActive)
    if not button or not button.GetFontString then return end
    button:GetFontString():SetTextColor(IsActive and 0 or 0.5, IsActive and 1 or 0.5, 0)
end

-- 更新按钮状态（保持不变）
function Hekili_Btn_UpdateButton()
    if not HekiliDisplayPrimary or areButtonsHidden then return end
    -- ...（原有逻辑不变）...
end

-- 切换按钮显示/隐藏（保持不变）
local function ToggleButtonsVisibility()
    areButtonsHidden = not areButtonsHidden
    for i = 1, 6 do
        local button = _G["Hekili_Btnbutton"..i]
        if button then button:SetShown(not areButtonsHidden) end
    end
    Hekili_ControlButton:SetText(areButtonsHidden and "▲" or "▼")
end

-- 拖动逻辑核心
local function StartDragging(self)
    isDragging = true
    dragStartX, dragStartY = GetCursorPosition()
    frameStartX, frameStartY = self:GetLeft(), self:GetTop()
    self:SetScript("OnUpdate", function()
        if isDragging then
            local x, y = GetCursorPosition()
            local dx = (x - dragStartX) / self:GetEffectiveScale()
            local dy = (y - dragStartY) / self:GetEffectiveScale()
            
            -- 移动控制按钮和按钮组
            Hekili_BtnFrame:ClearAllPoints()
            Hekili_BtnFrame:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", 
                frameStartX + dx, frameStartY + dy)
            
            -- 同步移动 Hekili 主显示框（如果存在）
            if HekiliDisplayPrimary then
                HekiliDisplayPrimary:ClearAllPoints()
                HekiliDisplayPrimary:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", 
                    frameStartX + dx, frameStartY + dy + 30) -- Y轴偏移30像素
            end
        end
    end)
end

local function StopDragging()
    isDragging = false
    Hekili_ControlButton:SetScript("OnUpdate", nil)
end

-- 创建按钮框架（新增拖动支持）
function Hekili_Btn_CreateBtnFrame()
    Hekili_BtnFrame = CreateFrame("Frame", "HekiliBtnFrame", UIParent)
    Hekili_BtnFrame:SetSize(120, 30)
    Hekili_BtnFrame:SetPoint("TOPLEFT", UIParent, "CENTER", 0, 0) -- 初始位置居中
    
    -- 控制按钮（支持拖动）
    Hekili_ControlButton = CreateFrame("Button", nil, Hekili_BtnFrame, "UIPanelButtonTemplate")
    Hekili_ControlButton:SetSize(20, 10)
    Hekili_ControlButton:SetPoint("TOPLEFT", 0, 0)
    Hekili_ControlButton:SetText("▼")
    Hekili_ControlButton:GetFontString():SetTextColor(1, 1, 1)
    
    -- 拖动相关事件
    Hekili_ControlButton:RegisterForDrag("LeftButton")
    Hekili_ControlButton:SetScript("OnDragStart", StartDragging)
    Hekili_ControlButton:SetScript("OnDragStop", StopDragging)
    Hekili_ControlButton:SetScript("OnClick", function(_, button)
        if button == "LeftButton" and not isDragging then
            ToggleButtonsVisibility()
        end
    end)
    
    -- 创建6个功能按钮（简化版）
    local buttons = {
        {text = "主", toggle = "cooldowns", x = 0},
        {text = "次", toggle = "essences", x = 20},
        {text = "断", toggle = "interrupts", x = 40},
        {text = "防", toggle = "defensives", x = 60},
        {text = "药", toggle = "potions", x = 80},
        {text = Hekili_mode_dict[Hekili.DB.profile.toggles.mode.value], toggle = "mode", x = 100}
    }
    
    for i, btnInfo in ipairs(buttons) do
        local btn = CreateFrame("Button", "Hekili_Btnbutton"..i, Hekili_BtnFrame, "UIPanelButtonTemplate")
        btn:SetSize(20, 20)
        btn:SetPoint("TOPLEFT", btnInfo.x, -10)
        btn:SetText(btnInfo.text)
        btn:SetScript("OnClick", function()
            Hekili:FireToggle(btnInfo.toggle)
            if i == 6 then
                btn:SetText(Hekili_mode_dict[Hekili.DB.profile.toggles.mode.value])
            end
            Hekili_Btn_UpdateButton()
        end)
    end
    
    Hekili_Btn_UpdateButton()
end

-- 初始化（延迟1秒）
C_Timer.After(1, function()
    if HekiliDisplayPrimary then
        Hekili_Btn_CreateBtnFrame()
        -- 初始位置关联（Hekili主窗口在按钮组下方30像素处）
        HekiliDisplayPrimary:ClearAllPoints()
        HekiliDisplayPrimary:SetPoint("TOPLEFT", Hekili_BtnFrame, "BOTTOMLEFT", 0, -10)
    end
end)

-- 状态更新（每0.2秒一次）
local frame = CreateFrame("Frame")
local lastUpdate = 0
frame:SetScript("OnUpdate", function(_, elapsed)
    lastUpdate = lastUpdate + elapsed
    if lastUpdate > 0.2 then
        Hekili_Btn_UpdateButton()
        lastUpdate = 0
    end
end)