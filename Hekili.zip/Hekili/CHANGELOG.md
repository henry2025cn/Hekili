# Hekili

## [v3.4.3-1.0.7](https://github.com/Hekili/hekili/tree/v3.4.3-1.0.7) (2024-04-20)
[Full Changelog](https://github.com/Hekili/hekili/compare/v3.4.3-1.0.6...v3.4.3-1.0.7) [Previous Releases](https://github.com/Hekili/hekili/releases)

- Merge pull request #3210 from Supernuss/wrath  
    Enhancer and ProtPala rotation update  
- Enhancer updated rota and minor fixes; ProtPala using clash instead of wait now  
- Ignore workspace  
- Tweaks to active\_dot and action.X.clash  
- Merge pull request #3013 from Supernuss/wrath  
    updated Shadow, Prot Warri, Prot Pala for P4  
- added active\_dot-check to DP generator  
- added multiple shared attributes, renamed debuff  
- updated Shadow, Prot Warri, Prot Pala for P4  
