Hekili_mode_dict = {
    single = "单",
    aoe = "群",
    dual = "双",
    reactive = "响",
    automatic = "自",
}

-- 全局变量：记录按钮是否隐藏
local areButtonsHidden = false

function ChangeButtonColor(button, IsActive)
    
    if not button or not button.GetFontString then return end  -- 添加空值检查

    local r, g, b
    if IsActive then
        r, g, b = 0, 1, 0
    else
        r, g, b = 0.5, 0.5, 0.5
    end
    button:GetFontString():SetTextColor(r, g, b)
end

function Hekili_Btn_UpdateButton()
    if not HekiliDisplayPrimary or areButtonsHidden then return end
    if HekiliDisplayPrimary then
        if Hekili_Btnbutton1 then ChangeButtonColor(Hekili_Btnbutton1, Hekili.DB.profile.toggles.cooldowns.value) end
        if Hekili_Btnbutton2 then ChangeButtonColor(Hekili_Btnbutton2, Hekili.DB.profile.toggles.essences.value) end
        if Hekili_Btnbutton3 then ChangeButtonColor(Hekili_Btnbutton3, Hekili.DB.profile.toggles.interrupts.value) end
        if Hekili_Btnbutton4 then ChangeButtonColor(Hekili_Btnbutton4, Hekili.DB.profile.toggles.defensives.value) end
        if Hekili_Btnbutton5 then ChangeButtonColor(Hekili_Btnbutton5, Hekili.DB.profile.toggles.potions.value) end 
        if Hekili_Btnbutton6 then
            Hekili_Btnbutton6:SetText(Hekili_mode_dict[Hekili.DB.profile.toggles.mode.value])
            ChangeButtonColor(Hekili_Btnbutton6, Hekili.DB.profile.toggles.mode.value)
        end
    end
end

-- 新增：切换按钮显示/隐藏
local function ToggleButtonsVisibility()
    areButtonsHidden = not areButtonsHidden
    for i = 1, 6 do
        local button = _G["Hekili_Btnbutton"..i]
        if button then
            button:SetShown(not areButtonsHidden)
        end
    end
    -- 更新控制按钮文本（▼表示隐藏，▲表示显示）
    if Hekili_ControlButton then
        Hekili_ControlButton:SetText(areButtonsHidden and "▲" or "▼")
    end
end

--控制按钮
function Hekili_Btn_CreateBtnFrame()
    Hekili_BtnFrame = CreateFrame("Frame", "BtnFrame")
    Hekili_BtnFrame:SetSize(20, 30)

    -- 新增：控制按钮（用于隐藏/显示其他按钮）
    Hekili_ControlButton = CreateFrame("Button", nil, Hekili_BtnFrame, "UIPanelButtonTemplate")
    Hekili_ControlButton:SetSize(20, 10)  -- 高度为长度的一半
    Hekili_ControlButton:SetPoint("TOPLEFT", 0, 0)
    Hekili_ControlButton:SetText("▼")
    Hekili_ControlButton:GetFontString():SetTextColor(1, 1, 1)  -- 白色文本
    Hekili_ControlButton:SetScript("OnClick", function(_, button)
        if button == "LeftButton" then
            ToggleButtonsVisibility()
        elseif button == "RightButton" then
        end
    end)

    Hekili_Btnbutton1 = CreateFrame("Button", "Hekili_BtnButton", Hekili_BtnFrame, "UIPanelButtonTemplate")
    Hekili_Btnbutton1:SetSize(20, 20)
    Hekili_Btnbutton1:SetPoint("TOPLEFT", Hekili_BtnFrame, "TOPLEFT", 0, -10)
    Hekili_Btnbutton1:SetText("主")
    Hekili_Btnbutton1:GetFontString():SetTextColor(0.5, 0.5, 0.5)
    Hekili_Btnbutton1:SetScript("OnClick", function()
        Hekili:FireToggle("cooldowns")
        Hekili_Btn_UpdateButton()
    end)

    Hekili_Btnbutton2 = CreateFrame("Button", "Hekili_BtnButton", Hekili_BtnFrame, "UIPanelButtonTemplate")
    Hekili_Btnbutton2:SetSize(20, 20)
    Hekili_Btnbutton2:SetPoint("TOPLEFT", Hekili_BtnFrame, "TOPLEFT", 20, -10)
    Hekili_Btnbutton2:SetText("次")
    Hekili_Btnbutton2:GetFontString():SetTextColor(0, 1, 0)
    Hekili_Btnbutton2:SetScript("OnClick", function()
        Hekili:FireToggle("essences")
        Hekili_Btn_UpdateButton()
    end)

    Hekili_Btnbutton3 = CreateFrame("Button", "Hekili_BtnButton", Hekili_BtnFrame, "UIPanelButtonTemplate")
    Hekili_Btnbutton3:SetSize(20, 20)
    Hekili_Btnbutton3:SetPoint("TOPLEFT", Hekili_BtnFrame, "TOPLEFT", 40, -10)
    Hekili_Btnbutton3:SetText("断")
    Hekili_Btnbutton3:GetFontString():SetTextColor(0, 1, 0)
    Hekili_Btnbutton3:SetScript("OnClick", function()
        Hekili:FireToggle("interrupts")
        Hekili_Btn_UpdateButton()
    end)

    Hekili_Btnbutton4 = CreateFrame("Button", "Hekili_BtnButton", Hekili_BtnFrame, "UIPanelButtonTemplate")
    Hekili_Btnbutton4:SetSize(20, 20)
    Hekili_Btnbutton4:SetPoint("TOPLEFT", Hekili_BtnFrame, "TOPLEFT", 60, -10)
    Hekili_Btnbutton4:SetText("防")
    Hekili_Btnbutton4:GetFontString():SetTextColor(0, 1, 0)
    Hekili_Btnbutton4:SetScript("OnClick", function()
        Hekili:FireToggle("defensives")
        Hekili_Btn_UpdateButton()
    end)

    Hekili_Btnbutton5 = CreateFrame("Button", "Hekili_BtnButton", Hekili_BtnFrame, "UIPanelButtonTemplate")
    Hekili_Btnbutton5:SetSize(20, 20)
    Hekili_Btnbutton5:SetPoint("TOPLEFT", Hekili_BtnFrame, "TOPLEFT", 80, -10)
    Hekili_Btnbutton5:SetText("药")
    Hekili_Btnbutton5:GetFontString():SetTextColor(0, 1, 0)
    Hekili_Btnbutton5:SetScript("OnClick", function()
        Hekili:FireToggle("potions")
        Hekili_Btn_UpdateButton()
    end)

    Hekili_Btnbutton6 = CreateFrame("Button", "Hekili_BtnButton", Hekili_BtnFrame, "UIPanelButtonTemplate")
    Hekili_Btnbutton6:SetSize(20, 20)
    Hekili_Btnbutton6:SetPoint("TOPLEFT", Hekili_BtnFrame, "TOPLEFT", 100, -10)
    Hekili_Btnbutton6:SetText(Hekili_mode_dict[Hekili.DB.profile.toggles.mode.value])
    Hekili_Btnbutton6:GetFontString():SetTextColor(0, 1, 0)
    Hekili_Btnbutton6:SetScript("OnClick", function()
        Hekili:FireToggle("mode")
        Hekili_Btnbutton6:SetText(Hekili_mode_dict[Hekili.DB.profile.toggles.mode.value])
    end)
    Hekili_Btn_UpdateButton()
end

C_Timer.After(1, function()
    if HekiliDisplayPrimary then
        Hekili_Btn_CreateBtnFrame()
        Hekili_BtnFrame:ClearAllPoints() -- 清除原来的位置
        Hekili_BtnFrame:SetPoint("TOPLEFT", HekiliDisplayPrimary, "TOPLEFT", 0, 30)
    end
end)

-- 优化后的 OnUpdate（降低频率）
local lastUpdate = 0
local frame = CreateFrame("Frame")
frame:SetScript("OnUpdate", function(_, elapsed)
    lastUpdate = lastUpdate + elapsed
    if lastUpdate > 0.2 then  -- 每0.2秒更新一次
        Hekili_Btn_UpdateButton()
        lastUpdate = 0
    end
end)
