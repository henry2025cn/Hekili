HP = {}

-- HP.GetSpecialization = function()
--     local numTabs = GetNumTalentTabs()  -- 获取天赋树数量
--     if not numTabs or numTabs == 0 then
--         --print("No talent tabs available.")
--         return nil  -- 返回 nil 表示无可用天赋树
--     end

--     local totalPoints = {}  -- 动态初始化点数数组

--     -- 遍历每个天赋树
--     for tabIndex = 1, numTabs do
--         totalPoints[tabIndex] = 0  -- 初始化当前天赋树点数
--         local numTalents = GetNumTalents(tabIndex)  -- 获取天赋数量
--         if numTalents and numTalents > 0 then
--             for talentIndex = 1, numTalents do
--                 local _, _, _, _, currentRank = GetTalentInfo(tabIndex, talentIndex)
--                 totalPoints[tabIndex] = totalPoints[tabIndex] + (currentRank or 0)
--             end
--         end
--     end

--     -- 找出点数最多的天赋树
--     local maxPoints = 0
--     local maxTabIndex = nil
--     for i = 1, numTabs do
--         if totalPoints[i] > maxPoints then
--             maxPoints = totalPoints[i]
--             maxTabIndex = i
--         end
--     end

--     if maxTabIndex then
--         return maxTabIndex  -- 返回点数最多的天赋树索引
--     else
--         --print("No points allocated in any talent tab.")
--         return 0  -- 如果没有分配点数，返回 0
--     end
-- end

-- HP.GetSpecializationInfo = function(index) 
--     local _, englishClass = UnitClass("player")
--     if englishClass == "PRIEST" then
--         if index == 1 then
--             return 256, "戒律"
--         elseif index == 2 then
--             return 257, "神圣"
--         elseif index == 3 then  
--             return 258, "暗影"
--         end

--     elseif englishClass == "DRUID" then
--         if index == 1 then
--             return 102, "平衡"
--         elseif index == 2 then
--             return 103, "野性战斗"
--         elseif index == 3 then  
--             return 105, "恢复"
--         end
--     elseif englishClass == "WARLOCK" then
--         if index == 1 then
--             return 265, "痛苦"
--         elseif index == 2 then
--             return 266, "恶魔学识"
--         elseif index == 3 then  
--             return 267, "毁灭"
--         end

--     elseif englishClass == "HUNTER" then  
--         if index == 1 then
--             return 253, "野兽控制"
--         elseif index == 2 then
--             return 254, "射击"
--         elseif index == 3 then  
--             return 255, "生存"
--         end  
    
--     elseif englishClass == "WARRIOR" then
--         if index == 1 then
--             return 71, "武器"
--         elseif index == 2 then
--             return 72, "狂怒"
--         elseif index == 3 then  
--             return 73, "防护"
--         end

--     elseif englishClass == "MAGE" then 
--         if index == 1 then
--             return 62, "奥术"
--         elseif index == 2 then
--             return 63, "火焰"
--         elseif index == 3 then  
--             return 64, "冰霜"
--         end

--     elseif englishClass == "ROGUE" then  
--         if index == 1 then
--             return 259, "奇袭"
--         elseif index == 2 then
--             return 260, "战斗"
--         elseif index == 3 then  
--             return 261, "敏锐"
--         end 

--     elseif englishClass == "PALADIN" then 
--         if index == 1 then
--             return 65, "神圣"
--         elseif index == 2 then
--             return 66, "防护"
--         elseif index == 3 then  
--             return 70, "惩戒"
--         end 

--     elseif englishClass == "SHAMAN" then   
--         if index == 1 then
--             return 262, "元素"
--         elseif index == 2 then
--             return 263, "增强"
--         elseif index == 3 then  
--             return 264, "恢复"
--         end
    
--     elseif englishClass == "DEATHKNIGHT" then   
--         if index == 1 then
--              return 250, "鲜血"
--         elseif index == 2 then
--              return 251, "冰霜"
--         elseif index == 3 then  
--              return 252, "邪恶"
--         end

--     end
-- end

HP.GetSpecialization = function()
    return GetActiveTalentGroup()
end

HP.GetSpecializationInfo = function(index) 
    local name, baseName, id = UnitClass( "player" )
    return id, baseName, name
end